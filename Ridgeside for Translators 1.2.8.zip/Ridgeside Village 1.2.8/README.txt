How to install:
1) Translate necessary texts
2) Copy files and overwrite main mod
3) Play